sde2.caml - Contains all the functions for the assignment
	first_duplicate: Finds the first integer that has a duplicate somewhere else in the list.
	first_nonrepeating: Finds the first integer that does not have a duplicate somewhere in the list.
	sumOfTwo: Given two integer lists and a sum, find if any number in list 1 can be added to a number in list 2 to create the designated sum.
	cyk_sublists: Given some number n, find all pairs of positive numbers that add up to n.

sde2.log - Contains two examples of each function in use

Honor Pledge - On my honor I have neither given nor received aid on this exam. 